RIHULA CONTRIBUTION CONFIRMATION UPDATE

Replace the existing script.js and admin.js with the files in this ZIP.

What changed:
- Before saving a contribution, the system looks up the member by phone number.
- It shows a confirmation such as:
  "Confirm contribution of Michael Okare?
   Amount: KSh 500
   Phone: 07xxxxxxxx"
- OK records the contribution.
- Cancel stops the recording.
- Unknown phone numbers are rejected before anything is saved.
- The existing admin push notification behavior is preserved in admin.js.
